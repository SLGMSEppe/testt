const fs = require('fs');
const yaml = require("js-yaml")
const config = yaml.load(fs.readFileSync('./config.yml', 'utf8'))
const color = require('ansi-colors');
const botVersion = require('../package.json');
const utils = require("../utils.js");
const Discord = require("discord.js");
const mongoose = require("mongoose");
const guildModel = require('../models/guildModel');

module.exports = async client => {
    let guild = await client.guilds.cache.get(config.GuildID)
    if(!guild) {
        await console.log('\x1b[31m%s\x1b[0m', `[ERROR] The guild ID specified in the config is invalid or the bot is not in the server!\nYou can use the link below to invite the bot to your server:\nhttps://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`)
        await process.exit()
    }


    const connectToMongoDB = async () => {
      try {
        if (config.MongoURI) await mongoose.set('strictQuery', false);
    
        if (config.MongoURI) {
          await mongoose.connect(config.MongoURI);
        } else {
          throw new Error('[ERROR] MongoDB Connection String is not specified in the config! (MongoURI)');
        }
      } catch (error) {
        console.error('\x1b[31m%s\x1b[0m', `[ERROR] Failed to connect to MongoDB: ${error.message}\n${error.stack}`);
    
        if (error.message.includes('authentication failed')) {
          await console.error('Authentication failed. Make sure to check if you entered the correct username and password in the connection URL.');
          await process.exit(1)
        } else if (error.message.includes('network error')) {
          await console.error('Network error. Make sure the MongoDB server is reachable and the connection URL is correct.');
          await process.exit(1)
        } else if (error.message.includes('permission denied')) {
          await console.error('Permission denied. Make sure the MongoDB cluster has the necessary permissions to read and write.');
          await process.exit(1)
        } else {
          await console.error('An unexpected error occurred. Check the MongoDB connection URL and credentials.');
          await process.exit(1)
        }
      }
    };
    connectToMongoDB();

// Create guild model if it doesn't exist and save to db
const gModel = await guildModel.findOne({ guildID: config.GuildID });
if (!gModel || gModel?.length == 0) {
  const newModel = new guildModel({
    guildID: config.GuildID,
    verificationMsgID: "",
    totalWarns: 0,
    totalKicks: 0,
    totalBans: 0,
    totalTimeouts: 0,
    totalActions: 0,
    totalMessages: 0,
    timesBotStarted: 0,
    recentMessages: []
  });
  await newModel.save();
}

const statsDB = await guildModel.findOne({ guildID: config.GuildID });

// Bot Activity
let activType;

switch (config.BotActivitySettings.Type) {
  case "WATCHING":
    activType = Discord.ActivityType.Watching;
    break;
  case "PLAYING":
    activType = Discord.ActivityType.Playing;
    break;
  case "COMPETING":
    activType = Discord.ActivityType.Competing;
    break;
}

if (config.BotActivitySettings.Enabled && config.BotActivitySettings.Statuses?.length > 0) {
  let index = 0;

  
  const setActivity = async () => {
    await client.user.setActivity(
      config.BotActivitySettings.Statuses[index]
        .replace(/{total-users}/g, `${guild.memberCount.toLocaleString('en-US')}`)
        .replace(/{total-channels}/g, `${client.channels.cache.size}`)
        .replace(/{total-actions}/g, `${statsDB.totalActions.toLocaleString('en-US')}`)
        .replace(/{total-messages}/g, `${statsDB.totalMessages.toLocaleString('en-US')}`)
        .replace(/{total-warns}/g, `${statsDB.totalWarns.toLocaleString('en-US')}`)
        .replace(/{total-timeouts}/g, `${statsDB.totalTimeouts.toLocaleString('en-US')}`)
        .replace(/{total-kicks}/g, `${statsDB.totalKicks.toLocaleString('en-US')}`)
        .replace(/{total-bans}/g, `${statsDB.totalBans.toLocaleString('en-US')}`),
      { type: activType }
    );
    index = (index + 1) % config.BotActivitySettings.Statuses.length;
  };

  setActivity();

  setInterval(setActivity, config.BotActivitySettings.Interval * 1000);
} else if (config.BotActivitySettings.Enabled && config.BotActivitySettings.Statuses?.length === 1) {
  client.user.setActivity(
    config.BotActivitySettings.Statuses[0]
    .replace(/{total-users}/g, `${guild.memberCount.toLocaleString('en-US')}`)
    .replace(/{total-channels}/g, `${client.channels.cache.size}`)
    .replace(/{total-actions}/g, `${statsDB.totalActions.toLocaleString('en-US')}`)
    .replace(/{total-messages}/g, `${statsDB.totalMessages.toLocaleString('en-US')}`)
    .replace(/{total-warns}/g, `${statsDB.totalWarns.toLocaleString('en-US')}`)
    .replace(/{total-timeouts}/g, `${statsDB.totalTimeouts.toLocaleString('en-US')}`)
    .replace(/{total-kicks}/g, `${statsDB.totalKicks.toLocaleString('en-US')}`)
    .replace(/{total-bans}/g, `${statsDB.totalBans.toLocaleString('en-US')}`),
    { type: activType }
  );
}

client.guilds.cache.forEach(guild => {
    if(!config.GuildID.includes(guild.id)) {
    guild.leave();
    console.log('\x1b[31m%s\x1b[0m', `[INFO] Someone tried to invite the bot to another server! I automatically left it (${guild.name})`)
    }
})
if (guild && !guild.members.me.permissions.has("Administrator")) {
    console.log('\x1b[31m%s\x1b[0m', `[ERROR] The bot doesn't have enough permissions! Please give the bot ADMINISTRATOR permissions in your server or it won't function properly!`)
}

await console.log("――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――");
await console.log("                                                                          ");
if(config.LicenseKey) await console.log(`${color.green.bold.underline(`Plex Staff v${botVersion.version} is now Online!`)} (${color.gray(`${config.LicenseKey.slice(0, -10)}`)})`);
if(!config.LicenseKey) await console.log(`${color.green.bold.underline(`Plex Staff v${botVersion.version} is now Online! `)}`);
await console.log(`• Join our discord server for support, ${color.cyan(`discord.gg/plexdev`)}`);
await console.log(`• By using this bot you agree to all terms located here, ${color.yellow(`plexdevelopment.net/tos`)}`);
await console.log(`• Addons for the bot can be found here, ${color.yellow(`plexdevelopment.net/store`)}`);
if(config.Statistics) await console.log("                                                                          ");
if(config.Statistics) await console.log(`${color.green.bold.underline(`Statistics:`)}`);
if(config.Statistics) await console.log(`• The bot has been started a total of ${color.cyan.underline(`${statsDB.timesBotStarted.toLocaleString('en-US')}` )} times.`);
if(config.Statistics) await console.log(`• A total of ${color.cyan.underline(`${statsDB.totalWarns.toLocaleString('en-US')}` )} warns have been issued.`);
if(config.Statistics) await console.log(`• A total of ${color.cyan.underline(`${statsDB.totalTimeouts.toLocaleString('en-US')}` )} timeouts have been issued.`);
if(config.Statistics) await console.log(`• A total of ${color.cyan.underline(`${statsDB.totalKicks.toLocaleString('en-US')}` )} kicks have been issued.`);
if(config.Statistics) await console.log(`• A total of ${color.cyan.underline(`${statsDB.totalBans.toLocaleString('en-US')}` )} bans have been issued.`);
if(config.Statistics) await console.log(`• A total of ${color.cyan.underline(`${statsDB.totalActions.toLocaleString('en-US')}` )} actions have been performed.`);
if(config.Statistics) await console.log(`• A total of ${color.cyan.underline(`${statsDB.totalMessages.toLocaleString('en-US')}` )} messages have been sent.`);
if(config.LicenseKey) await console.log("                                                                          ");
if(config.LicenseKey) await console.log(`${color.green.bold.underline(`Source Code:`)}`);
if(config.LicenseKey) await console.log(`• You can buy the full source code at ${color.yellow(`plexdevelopment.net/store/pssourcecode`)}`);
if(config.LicenseKey) await console.log(`• Use code ${color.green.bold.underline(`PLEX`)} for 10% OFF!`);
await console.log("                                                                          ");
await console.log("――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――");
await utils.checkConfig(client)

await console.log(color.red.bold("WARNING:"));
await console.log(color.yellow.bold("Since Plex Staff handles all moderation functions, punishment history, staff member action limits, appeals, and so much more, it's recommended to disable the kick/ban/timeout permissions from your staff members' Discord roles. Instead, only allow them to use Plex Staff commands and the dashboard (with Plex Staff built-in permission system). Plex Staff is not able to handle the built-in Discord ban/kick/timeout functions. If they use those, the punishment won't be logged, the appeal system won't function, and action limits won't work."));
await console.log("");
    // BETA NOTICE
/*     console.log(color.red.bold("NOTICE:"));
    console.log(color.yellow.bold("You are currently using a closed beta version of Plex Staff."));
    console.log(color.yellow.bold("This does not represent the final product; it is bound to have issues and bugs, and any features/design are subject to change."));
    console.log(color.yellow.bold("Report bugs and provide feedback in our Discord server."));
    console.log(color.yellow.bold("Additional Information:"));
    console.log(color.yellow.bold("- This version may contain experimental features and functionalities."));
    console.log(color.yellow.bold("- Your participation in this beta helps us improve and refine the final product."));
    console.log(color.yellow.bold("- Expect frequent updates and changes as we iterate based on user feedback."));
    console.log(color.yellow.bold("- Access to this beta version is extremely limited and carefully selected, with only a very limited amount of users."));
    console.log(color.yellow.bold("- This version is unreleased, and sharing the files or any details about this product with anyone that is not a part of the BETA team is strictly forbidden."));
 */
let logMsg = `\n\n[${new Date().toLocaleString()}] [READY] Bot is now ready!`;
fs.appendFile("./logs.txt", logMsg, (e) => { 
  if(e) console.log(e);
});

if(config.Dashboard.Enabled) {
  require("../dashboard/app.js");
}

// Send verification embed to channel
if (config.VerificationSettings.Enabled) {
  guildModel.findOne({ guildID: guild.id })
      .then(guildData => {
          let verifData = guildData;

          let channel = guild.channels.cache.get(config.VerificationSettings.ChannelID);

          if (!channel) console.log('\x1b[31m%s\x1b[0m', `[ERROR] VerificationSettings.ChannelID is not a valid channel!`);
          
          const button = new Discord.ButtonBuilder()
              .setCustomId('verifButton')
              .setLabel(config.VerificationButton.Name)
              .setStyle(config.VerificationButton.Color)
              .setEmoji(config.VerificationButton.Emoji);
          let row = new Discord.ActionRowBuilder().addComponents(button);

          const verifEmbed = new Discord.EmbedBuilder()
          if(config.VerificationEmbed.Embed.Title) verifEmbed.setTitle(config.VerificationEmbed.Embed.Title)
          verifEmbed.setDescription(config.VerificationEmbed.Embed.Description)
          if(config.VerificationEmbed.Embed.Color) verifEmbed.setColor(config.VerificationEmbed.Embed.Color)
          if(!config.VerificationEmbed.Embed.Color) verifEmbed.setColor(config.EmbedColors)
          if(config.VerificationEmbed.Embed.PanelImage) verifEmbed.setImage(config.VerificationEmbed.Embed.PanelImage)
          if(config.VerificationEmbed.Embed.CustomThumbnailURL) verifEmbed.setThumbnail(config.VerificationEmbed.Embed.CustomThumbnailURL)
          if(config.VerificationEmbed.Embed.Footer.Enabled && config.VerificationEmbed.Embed.Footer.text) verifEmbed.setFooter({ text: `${config.VerificationEmbed.Embed.Footer.text}` })
          if(config.VerificationEmbed.Embed.Footer.Enabled && config.VerificationEmbed.Embed.Footer.text && config.VerificationEmbed.Embed.Footer.CustomIconURL) verifEmbed.setFooter({ text: `${config.VerificationEmbed.Embed.Footer.text}`, iconURL: `${config.VerificationEmbed.Embed.Footer.CustomIconURL}` })
          if(config.VerificationEmbed.Embed.Timestamp) verifEmbed.setTimestamp()

          if (channel && !verifData.verificationMsgID) {
              channel.send({ embeds: [verifEmbed], components: [row] })
                  .then(async function (msg) {
                      verifData.verificationMsgID = msg.id;
                      await verifData.save();
                  })
                  .catch(error => {
                      console.error(error);
                  });
          }

          if (channel && verifData.verificationMsgID) {
              channel.messages.fetch(verifData.verificationMsgID)
                  .catch(error => {
                      channel.send({ embeds: [verifEmbed], components: [row] })
                          .then(async function (msg2) {
                              verifData.verificationMsgID = msg2.id;
                              await verifData.save();
                          })
                          .catch(error => {
                              console.error(error);
                          });
                  });
          }
      })
      .catch(error => {
          console.error(error);
      });
}

    // Increase timesBotStarted by 1 everytime the bot starts
    statsDB.timesBotStarted++;
    await statsDB.save();

    // Send first start message
    if(statsDB.timesBotStarted === 1) {
      console.log(``)
      console.log(``)
      console.log(`Thank you for choosing ${color.yellow('Plex Staff')}!`)
      console.log(`Since this is your first time starting the bot, Here is some important information:`)
      console.log(``)
      console.log(`If you need any help, Create a ticket in our discord server.`)
      console.log(`You can also look at our documentation for help, ${color.yellow(`docs.plexdevelopment.net`)}`)
      console.log(``)
      console.log(`${color.bold.red(`WARNING:\n Leaking, redistributing or re-selling any of our products is not allowed \nYour actions may have legal consequences if you violate our terms.\nif you are found doing it, your license will be permanently disabled!`)}`)
      console.log(`By using this bot you agree to all terms located here, ${color.yellow(`plexdevelopment.net/tos`)}`)
    }

}
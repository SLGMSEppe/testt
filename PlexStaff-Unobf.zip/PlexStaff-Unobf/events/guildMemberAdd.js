const fs = require('fs');
const yaml = require("js-yaml")
const config = yaml.load(fs.readFileSync('./config.yml', 'utf8'))
const utils = require("../utils.js");
const Discord = require("discord.js");
const guildModel = require('../models/guildModel');
const userModel = require('../models/userModel');
const ms = require('ms');

module.exports = async (client, member) => {

    utils.incrementStats(new Date(), 'memberJoins')

    if(config.AltPrevention.Enabled) {
        if (Date.now() - member.user.createdAt < ms(config.AltPrevention.TimeLimit)) {

            let punishmentID = await utils.generatePunishmentID();
            if (config.AltPrevention.Punishment === "Kick") {
                const { success, message } = await utils.kickUser(member, client.user, config.AltPrevention.Reason, punishmentID);
                if (!success) {
                    console.error("Failed to kick user:", message);
                }
            }
            
            if (config.AltPrevention.Punishment === "Ban") {
                const { success, message } = await utils.banUser(member, client.user, config.AltPrevention.Reason, punishmentID);
                if (!success) {
                    console.error("Failed to ban user:", message);
                }
            }
    }
}

};
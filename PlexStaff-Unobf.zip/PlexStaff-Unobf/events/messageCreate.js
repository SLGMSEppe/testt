const fs = require('fs');
const yaml = require("js-yaml")
const config = yaml.load(fs.readFileSync('./config.yml', 'utf8'))
const color = require('ansi-colors');
const botVersion = require('../package.json');
const utils = require("../utils.js");
const Discord = require("discord.js");
const mongoose = require("mongoose");
const guildModel = require('../models/guildModel');
const userModel = require('../models/userModel');
const emojiRegex = require('emoji-regex');

module.exports = async (client, message) => {
    if (message.author.bot) return;
    if(!message.channel.type === 0) return;

    utils.incrementStats(new Date(), 'messagesSent')

    try {
        // Find or create the user
        let user = await userModel.findOne({ userID: message.author.id });
        let guildDB = await guildModel.findOne({ guildID: message.guild.id });

        if (!user) {
            user = await userModel.create({
                userID: message.author.id,
                totalMessages: 1,
                totalEmojisUsed: 0,
                messageHistory: [],
            });
        } else {
            // Increment totalMessages by 1
            user.totalMessages += 1;
        }

        await guildModel.findOneAndUpdate({ guildID: message.guild.id }, { $inc: { totalMessages: 1 } });

        if(config.GeneralSettings.SaveRecentMessages) {

          const channelId = message.channel.id;
          const categoryId = message.channel.parentId;
          let saveGlobalMessages = true;

          if (
            (config.AutoResponse.BlacklistedChannels && config.AutoResponse.BlacklistedChannels.includes(channelId)) ||
            (config.AutoResponse.BlacklistedCategories && config.AutoResponse.BlacklistedCategories.includes(categoryId))
          ) {
            saveGlobalMessages = false;
          }

        // Check if the message contains an attachment
        if (message.attachments.size > 0) {
            // Iterate over each attachment
            message.attachments.forEach(attachment => {
                // Check if the attachment is an image or a file
                if (attachment.url) {
                    // Save the attachment URL to the message history
                    user.messageHistory.push({
                        channelName: message.channel.name,
                        message: attachment.url,
                        timestamp: message.createdAt,
                    });

                    if(saveGlobalMessages) {
                    guildDB.recentMessages.push({
                      channelName: message.channel.name,
                      channelID: message.channel.id,
                      userID: message.author.id,
                      msgID: message.id,
                      message: attachment.url,
                      timestamp: message.createdAt,
                  });
                }

                }
            });
          } else if (message.content.trim()) {
            // Add the message to the user's message history
            user.messageHistory.push({
                channelName: message.channel.name,
                message: message.content,
                timestamp: message.createdAt,
            });

            if(saveGlobalMessages) {
            guildDB.recentMessages.push({
              channelName: message.channel.name,
              channelID: message.channel.id,
              userID: message.author.id,
              msgID: message.id,
              message: message.content,
              timestamp: message.createdAt,
          });
        }

        }

            // Count standard emojis in the message content
            const standardEmojisUsed = message.content.match(emojiRegex());
            if (standardEmojisUsed) {
                // Increment totalEmojisUsed by the number of standard emojis found in the message
                user.totalEmojisUsed += standardEmojisUsed.length;
            }

            // Count custom emojis in the message content
            const customEmojisUsed = message.content.match(/<:[a-zA-Z0-9_]+:[0-9]+>/g);
            if (customEmojisUsed) {
                // Increment totalEmojisUsed by the number of custom emojis found in the message
                user.totalEmojisUsed += customEmojisUsed.length;
            }

        // Keep only the last specified amount of messages
        if (user.messageHistory.length > config.GeneralSettings.RecentMessagesLimit) {
            const excessMessages = user.messageHistory.length - config.GeneralSettings.RecentMessagesLimit;
            user.messageHistory.splice(0, excessMessages);
        }

        if(saveGlobalMessages) {
        if (guildDB.recentMessages.length > config.OverviewPage.messageLimit) {
          const excessMessages = guildDB.recentMessages.length - config.OverviewPage.messageLimit;
          guildDB.recentMessages.splice(0, excessMessages);
      }
    }

        await user.save();
        await guildDB.save();
      }
    } catch (error) {
        console.error('Error in messageCreate event:', error);
    }

// Auto Responses
if (config.AutoResponse.Enabled) {
    const channelId = message.channel.id;
    const categoryId = message.channel.parentId;

    if (
      (config.AutoResponse.BlacklistedChannels && config.AutoResponse.BlacklistedChannels.includes(channelId)) ||
      (config.AutoResponse.BlacklistedCategories && config.AutoResponse.BlacklistedCategories.includes(categoryId))
    ) {
      return;
    }
  
    const validWhitelistedChannels = config.AutoResponse.WhitelistedChannels.every(channelId => {
      if(channelId && config.AutoResponse.WhitelistedChannels && message?.guild) return message.guild.channels.cache.has(channelId);
    });

    if (config.AutoResponse.WhitelistedChannels && validWhitelistedChannels) return;

    for (const [initiator, responseData] of Object.entries(config.AutoResponse.Responses)) {
      if (message.content.toLowerCase().includes(initiator.toLowerCase()) || message.content.toLowerCase().startsWith(initiator.toLowerCase())) {
        const respMsg = responseData.Message.replace('{user}',`<@!${message.author.id}>`)
        .replace('{username}', message.author.username)
        .replace('{userID}', message.author.id)
        .replace('{guildName}', message.guild.name)
        .replace('{channelName}', message.channel.name)
        .replace('{initiator-message}', initiator.toLowerCase())
        .replace('{channelID}', message.channel.id);
        const responseType = responseData.Type || config.AutoResponse.MessageType;

        if (responseType === "EMBED") {
          // Send response as an embed
          const respEmbed = new Discord.EmbedBuilder()
            .setColor(config.EmbedColors)
            .setDescription(`${respMsg}`)
            .setFooter({ text: message.author.username, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
            .setTimestamp();
  
          if(config.AutoResponse.replyToUser) message.reply({ embeds: [respEmbed] });
          if(!config.AutoResponse.replyToUser) message.channel.send({ embeds: [respEmbed] });
        } else if (responseType === "TEXT") {
          // Send response as plain text
          if(config.AutoResponse.replyToUser) message.reply({ content: respMsg });
          if(!config.AutoResponse.replyToUser) message.channel.send({ content: respMsg });
        } else {
          console.log("Invalid message type for auto response message specified in the config!");
        }
  
        break; 
      }
    }
}






  
  

};
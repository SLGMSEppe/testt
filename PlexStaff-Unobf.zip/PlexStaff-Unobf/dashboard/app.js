const express = require('express');
const session = require('express-session');
const MongoStore = require('connect-mongo');

const bodyParser = require('body-parser');
const passport = require('passport');
const DiscordStrategy = require('passport-discord');
const Discord = require('discord.js');
const fs = require('fs');
const yaml = require("js-yaml")
const config = yaml.load(fs.readFileSync('./config.yml', 'utf8'))
const { client } = require("../index.js")
const path = require('path');
const staffModel = require('../models/staffModel');
const guildModel = require('../models/guildModel');
const Cooldown = require('../models/cooldownModel');
const dashboardModel = require("../models/dashboardModel");
const statsModel = require('../models/statisticsModel');
const appealModel = require('../models/appealModel');
const punishmentModel = require("../models/punishmentModel");
const userModel = require("../models/userModel");
const flash = require('express-flash');
const utils = require("../utils.js");
const axios = require('axios');
const color = require('ansi-colors');
const cookieParser = require('cookie-parser');
const ms = require('parse-duration');

const app = express();

const PORT = config.Dashboard.Port || 3000;

async function createDashboardDocument() {
    // Create dashboard model if it doesn't exist and save to db
    const dModel = await dashboardModel.findOne({ guildID: config.GuildID });
    if (!dModel || dModel?.length == 0) {
      const newModel = new dashboardModel({
        guildID: config.GuildID,
        url: config.Dashboard.URL,
        port: PORT,
      });
      await newModel.save();
    } else if(dModel) {
      // Update the existing dashboard model
      dModel.url = config.Dashboard.URL;
      dModel.port = PORT;
      await dModel.save();
    }
}
    createDashboardDocument()

// Configure Express
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
    secret: config.Dashboard.secretKey,
    resave: false,
    saveUninitialized: false,
    store: MongoStore.create({ 
        mongoUrl: config.MongoURI,
        ttl: ms(config.Dashboard.SessionExpires),
        autoRemove: 'native'
    }),

    cookie: {
        secure: config.Dashboard.Secure,
        maxAge: ms(config.Dashboard.SessionExpires)
    }
}));
app.use(cookieParser())
app.use(flash());

app.use(passport.initialize());
app.use(passport.session());
app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');

const publicPath = path.join(__dirname, 'public');
app.use(express.static(publicPath));

// Passport Configuration
passport.use(new DiscordStrategy({
    clientID: config.Dashboard.clientID,
    clientSecret: config.Dashboard.clientSecret,
    callbackURL: config.Dashboard.callbackURL,
    scope: ['identify'],
}, (accessToken, refreshToken, profile, done) => {
    return done(null, profile);
}));

passport.serializeUser((user, done) => {
    done(null, user);
});

passport.deserializeUser((obj, done) => {
    done(null, obj);
});


app.get('/auth/discord', passport.authenticate('discord'));
app.get('/auth/discord/callback', passport.authenticate('discord', { failureRedirect: '/login' }), (req, res) => {
    const redirectUrl = req.cookies['redirectAfterLogin'] || '/';

    if(config.DashboardLogs) {
      // Log the login event to the console
      const consoleLogMsg = `${color.yellow(`[DASHBOARD] ${color.cyan(`${req.user.username} (${req.user.id})`)} logged in`)}`;
      console.log(consoleLogMsg);
  
      // Log the login event to a file
      const fileLogMsg = `\n[${new Date().toLocaleString()}] [DASHBOARD] ${req.user.username} (${req.user.id}) logged in`;
      fs.appendFile("./logs.txt", fileLogMsg + '\n', (error) => {
        if (error) console.error('Error logging login event:', error);
      });
    }

    res.redirect(redirectUrl);
  });

// Get Plex Staff version
const packageJsonPath = path.join(__dirname, '..', 'package.json');
const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));
const discordBotVersion = packageJson.version;
app.locals.discordBotVersion = discordBotVersion;

const isLoggedIn = (permissions) => async (req, res, next) => {
    try {
        if (req.isAuthenticated()) {
            const userID = req.user.id;

            const guild = await client.guilds.cache.get(config.GuildID);

            try {
                const member = await guild.members.fetch(req.user.id);
            } catch (error) {
                return res.render('error', { config, errorMessage: 'You must be a member of our Discord server to access this dashboard!' });
            }

            // Check if permissions array is defined and not empty
            if (permissions && permissions.length > 0) {
                const permissionsStatus = await Promise.all(permissions.map(async (permission) => {
                    return { [permission]: await utils.checkPermission(userID, permission) };
                }));
                const permissionsMap = Object.assign({}, ...permissionsStatus);
                res.locals.permissions = permissionsMap;
            }

            const hasPermission = await utils.checkPermission(req.user.id, "ACCESS_DASHBOARD");

            if (!hasPermission) {
                return res.render('error', { config, errorMessage: `You don't have enough permissions to access this dashboard!` });
            }

            return next(); // User is authenticated and has permissions, proceed to the next middleware/route
        } else {
            res.cookie('redirectAfterLogin', req.originalUrl);
            res.redirect(`/login`);
        }
    } catch (error) {
        console.error('Error checking permissions:', error);
        res.locals.permissions = {}; // Set to empty object in case of error
        res.render('error', { config, errorMessage: 'An error occurred while checking permissions!' });
    }
};


const requireLogin = async (req, res, next) => {
    try {
        if (req.isAuthenticated()) {
            // User is authenticated, proceed to the next middleware/route
            return next();
        } else {
            // User is not authenticated, redirect to the login page
            res.cookie('redirectAfterLogin', req.originalUrl);
            res.redirect(`/login`);
        }
    } catch (error) {
        console.error('Error checking authentication status:', error);
        res.render('error', { config, errorMessage: 'An error occurred while checking authentication status!' });
    }
};


app.get('/login', (req, res) => {
    res.render('login', { config: config });
});

app.get('/home', isLoggedIn(['VIEW_RECENT_PUNISHMENTS']), async (req, res) => {
    try {
        const guildId = config.GuildID;
        const guild = client.guilds.cache.get(guildId);

        if(config.DashboardLogs) {
    // Log the viewing page event to the console
    const consoleLogMsg = `${color.yellow(`[DASHBOARD] ${color.cyan(`${req.user.username} (${req.user.id})`)} accessed ${color.cyan('/home')} page`)}`;
    console.log(consoleLogMsg);

    // Log the viewing page event to a file
    const fileLogMsg = `\n[${new Date().toLocaleString()}] [DASHBOARD] ${req.user.username} (${req.user.id}) accessed /home page`;
    fs.appendFile("./logs.txt", fileLogMsg + '\n', (error) => {
      if (error) console.error('Error logging event:', error);
    });
}

        // Fetch guild stats from the database
        const guildData = await guildModel.findOne({ guildID: guildId });

        async function getDiscordUsername(userId, punishment) {
            try {
                const member = await guild.members.fetch(userId);
                return member.user.username;
            } catch (error) {
                // If fetching member from Discord fails, try fetching username from the database
                if (punishment.userID === userId) {
                    return punishment.username || 'Unknown';
                } else if (punishment.staff === userId) {
                    return punishment.staffUsername || 'Unknown';
                }
                return 'Unknown';
            }
        }

        function getRelativeTime(date) {
            const currentDate = new Date();
            const targetDate = new Date(date);
            const timeDifference = currentDate.getTime() - targetDate.getTime();
        
            const seconds = Math.floor(timeDifference / 1000);
            const minutes = Math.floor(seconds / 60);
            const hours = Math.floor(minutes / 60);
            const days = Math.floor(hours / 24);
        
            if (days > 0) {
                return days === 1 ? '1 day ago' : `${days} days ago`;
            } else if (hours > 0) {
                return hours === 1 ? '1 hour ago' : `${hours} hours ago`;
            } else if (minutes > 0) {
                return minutes === 1 ? '1 minute ago' : `${minutes} minutes ago`;
            } else {
                return seconds <= 20 ? 'just now' : `${seconds} seconds ago`;
            }
        }

        // Get the current logged-in user's member information
        const user = await guild.members.cache.get(req.user.id);
        const staffInfo = await staffModel.findOne({ userId: req.user.id });

        // Merge staffInfo into the user object
        if (staffInfo) {
            Object.assign(user, {
                roleName: staffInfo.roleName,
            });
        }

        // Function to convert user ID to Discord username
        async function getUsername(userId, punishment) {
            return await getDiscordUsername(userId, punishment);
        }

        // Fetch recent punishments from the database
        const recentPunishments = await punishmentModel.find({}).sort({ date: -1 }).limit(7);

        // Map over recent punishments to get real Discord usernames
        const recentPunishmentsWithUsernames = await Promise.all(recentPunishments.map(async (punishment) => {
            return {
                ...punishment.toObject(),
                userID: await getUsername(punishment.userID, punishment),
                staff: await getUsername(punishment.staff, punishment)
            };
        }));

        const chartData = await statsModel.find();

        res.render('home', { user, guild, chartData, config, guildData, recentPunishments: recentPunishmentsWithUsernames, getRelativeTime, permissions: res.locals.permissions });
    } catch (err) {
        console.error('Error fetching guild data:', err);
        res.status(500).send('Internal Server Error');
    }
});

app.get('/stats', isLoggedIn(), async (req, res) => {

    const hasPermission = await utils.checkPermission(req.user.id, "VIEW_STATS");
    if(!hasPermission) return res.render('error', { config, errorMessage: `You don't have enough permissions to access this page!` });

    if(config.DashboardLogs) {
    // Log the viewing page event to the console
    const consoleLogMsg = `${color.yellow(`[DASHBOARD] ${color.cyan(`${req.user.username} (${req.user.id})`)} accessed ${color.cyan('/stats')} page`)}`;
    console.log(consoleLogMsg);

    // Log the viewing page event to a file
    const fileLogMsg = `\n[${new Date().toLocaleString()}] [DASHBOARD] ${req.user.username} (${req.user.id}) accessed /stats page`;
    fs.appendFile("./logs.txt", fileLogMsg + '\n', (error) => {
      if (error) console.error('Error logging event:', error);
    });
}

    try {
        const guildId = config.GuildID;
        const guild = client.guilds.cache.get(guildId);

        // Fetch guild stats from the database
        const guildData = await guildModel.findOne({ guildID: guildId });
        const guildOwner = await guild.fetchOwner();

        // Get the current logged-in user's member information
        const user = await guild.members.cache.get(req.user.id);
        const staffInfo = await staffModel.findOne({ userId: req.user.id });

// Fetch top users based on total messages and total emojis used
const topUsersData = await userModel.find().sort({ totalMessages: -1, totalEmojisUsed: -1 }).limit(20);
const userDataPromises = topUsersData.map(async (userData) => {
    try {
        const fetchedUser = await client.users.fetch(userData.userID);
        return {
            username: fetchedUser.username,
            userID: fetchedUser.id,
            avatarURL: fetchedUser.avatarURL({ format: 'png', size: 256 }) || 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/fd/Faenza-avatar-default-symbolic.svg/2048px-Faenza-avatar-default-symbolic.svg.png',
            totalMessages: userData.totalMessages,
            totalEmojisUsed: userData.totalEmojisUsed
        };
    } catch (error) {
        //console.error(`Error fetching user data for user with ID ${userData.userID}:`, error);
        return {
            username: 'Unknown User',
            userID: userData.userID,
            avatarURL: 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/fd/Faenza-avatar-default-symbolic.svg/2048px-Faenza-avatar-default-symbolic.svg.png',
            totalMessages: userData.totalMessages,
            totalEmojisUsed: userData.totalEmojisUsed
        };
    }
});

const userData = await Promise.all(userDataPromises);

// Separate the top users based on total messages and total emojis used
const topUsers = userData
  .filter(user => user.totalMessages > 0)
  .sort((a, b) => b.totalMessages - a.totalMessages)
  .slice(0, 10);

// Separate the top users based on total messages and total emojis used
const topEmojisUsed = userData
  .filter(user => user.totalEmojisUsed > 0) 
  .sort((a, b) => b.totalEmojisUsed - a.totalEmojisUsed)
  .slice(0, 10);

        // Merge staffInfo into the user object
        if (staffInfo) {
            Object.assign(user, {
                roleName: staffInfo.roleName,
            });
        }

        function getRelativeTime(date) {
            const currentDate = new Date();
            const targetDate = new Date(date);
            const timeDifference = currentDate.getTime() - targetDate.getTime();
        
            const seconds = Math.floor(timeDifference / 1000);
            const minutes = Math.floor(seconds / 60);
            const hours = Math.floor(minutes / 60);
            const days = Math.floor(hours / 24);
        
            if (days > 0) {
                return days === 1 ? '1 day ago' : `${days} days ago`;
            } else if (hours > 0) {
                return hours === 1 ? '1 hour ago' : `${hours} hours ago`;
            } else if (minutes > 0) {
                return minutes === 1 ? '1 minute ago' : `${minutes} minutes ago`;
            } else {
                return seconds <= 20 ? 'just now' : `${seconds} seconds ago`;
            }
        }

        const chartData = await statsModel.find();

        res.render('stats', { user, chartData, guildOwner, guild, topUsers, topEmojisUsed, config, getRelativeTime, guildData, permissions: res.locals.permissions });
    } catch (err) {
        console.error('Error fetching guild data:', err);
        res.status(500).send('Internal Server Error');
    }
});

app.get('/logout', (req, res) => {

    if(config.DashboardLogs) {
    // Log the logout event to the console
    const consoleLogMsg = `${color.yellow(`[DASHBOARD] ${color.cyan(`${req.user.username} (${req.user.id})`)} logged out`)}`;
    console.log(consoleLogMsg);

    // Log the logout event to a file
    const fileLogMsg = `\n[${new Date().toLocaleString()}] [DASHBOARD] ${req.user.username} (${req.user.id}) logged out`;
    fs.appendFile("./logs.txt", fileLogMsg + '\n', (error) => {
      if (error) console.error('Error logging logout event:', error);
    });
}

    // Clear the saved redirect URL when logging out
    res.clearCookie('redirectAfterLogin');
    req.logout((err) => {
      if (err) {
        console.error('Error during logout:', err);
        return next(err);
      }
      res.redirect('/');
    });
  });

  app.get('/members', isLoggedIn(), async (req, res) => {
    const guildId = config.GuildID;
    const guild = client.guilds.cache.get(guildId);
    const memberCountWithoutBots = guild.members.cache.filter(member => !member.user.bot).size;
    const memberCount = memberCountWithoutBots.toLocaleString('en-US');

    if(config.DashboardLogs) {
        // Log the viewing page event to the console
        const consoleLogMsg = `${color.yellow(`[DASHBOARD] ${color.cyan(`${req.user.username} (${req.user.id})`)} accessed ${color.cyan('/members')} page`)}`;
        console.log(consoleLogMsg);
    
        // Log the viewing page event to a file
        const fileLogMsg = `\n[${new Date().toLocaleString()}] [DASHBOARD] ${req.user.username} (${req.user.id}) accessed /members page`;
        fs.appendFile("./logs.txt", fileLogMsg + '\n', (error) => {
          if (error) console.error('Error logging event:', error);
        });
    }

    // Ensure that all members are fetched and cached
    await guild.members.fetch();

    const membersPerPage = 100;
    const page = parseInt(req.query.page) || 1;
    const searchQuery = req.query.search || '';
    const filterOption = req.query.sort || 'highestRole';

    const startIndex = (page - 1) * membersPerPage;
    const endIndex = startIndex + membersPerPage;

    // Exclude bots from the entire user list
    const allMembers = Array.from(guild.members.cache.values());
    const filteredMembers = allMembers
        .filter(member => !member.user.bot)
        .filter(member => {
            const usernameMatch = member.user.username.toLowerCase().includes(searchQuery.toLowerCase());
            const nicknameMatch = member.nickname && member.nickname.toLowerCase().includes(searchQuery.toLowerCase());
            const userIdMatch = member.user.id.includes(searchQuery);

            return usernameMatch || nicknameMatch || userIdMatch;
        })
        .sort((a, b) => {
            if (filterOption === 'highestRole') {
                // Sort by role (highest to lowest)
                return b.roles.highest.position - a.roles.highest.position;
            } else if (filterOption === 'creationDateNewest') {
                // Sort by newest account creation date
                return b.user.createdTimestamp - a.user.createdTimestamp;
            } else if (filterOption === 'creationDateOldest') {
                // Sort by oldest account creation date
                return a.user.createdTimestamp - b.user.createdTimestamp;
            } else if (filterOption === 'joinDateNewest') {
                // Sort by newest joined server date
                return b.joinedTimestamp - a.joinedTimestamp;
            } else if (filterOption === 'joinDateOldest') {
                // Sort by oldest joined server date
                return a.joinedTimestamp - b.joinedTimestamp;
            } else {
                return 0;
            }
        });

    // Paginate the filtered members
    const members = filteredMembers.slice(startIndex, endIndex);

    const totalMembers = filteredMembers.length;
    const totalPages = Math.ceil(totalMembers / membersPerPage);

    // Get the current logged-in user's member information
    const user = await guild.members.cache.get(req.user.id);
    const staffInfo = await staffModel.findOne({ userId: req.user.id });
    
    // Merge staffInfo into the user object
    if (staffInfo) {
        Object.assign(user, {
            roleName: staffInfo.roleName,
        });
    }

    const staffMembers = await staffModel.find({});

    res.render('members', { members, currentPage: page, totalPages, user: user, sortOption: filterOption, memberCount, config, staffMembers });
});

app.get('/staff', isLoggedIn(), async (req, res) => {
    const guild = client.guilds.cache.get(config.GuildID);

    const hasPermission = await utils.checkPermission(req.user.id, "MANAGE_STAFF_MEMBERS");
    if (!hasPermission) return res.render('error', { config, errorMessage: `You don't have enough permissions to access this page!` });

    if(config.DashboardLogs) {
        // Log the viewing page event to the console
        const consoleLogMsg = `${color.yellow(`[DASHBOARD] ${color.cyan(`${req.user.username} (${req.user.id})`)} accessed ${color.cyan('/staff')} page`)}`;
        console.log(consoleLogMsg);
    
        // Log the viewing page event to a file
        const fileLogMsg = `\n[${new Date().toLocaleString()}] [DASHBOARD] ${req.user.username} (${req.user.id}) accessed /staff page`;
        fs.appendFile("./logs.txt", fileLogMsg + '\n', (error) => {
          if (error) console.error('Error logging event:', error);
        });
    }
    
    try {
        const existingStaffMembers = await staffModel.find();
        const totalStaffMembers = await staffModel.countDocuments();

        const staffWithStats = await Promise.all(existingStaffMembers.map(async (member) => {
            try {
                const punishments = await punishmentModel.find({ staff: member.userId });
    
                // Count the number of each punishment type
                const stats = {
                    Warns: punishments.filter(punishment => punishment.punishment === 'Warn').length || 0,
                    Kicks: punishments.filter(punishment => punishment.punishment === 'Kick').length || 0,
                    Timeouts: punishments.filter(punishment => punishment.punishment === 'Timeout').length || 0,
                    Bans: punishments.filter(punishment => punishment.punishment === 'Ban').length || 0,
                };
    
                // Fetch user details (username and avatarURL)
                const staffUser = await client.users.fetch(member.userId);
                
                return {
                    ...member.toObject(),
                    username: staffUser.username,
                    avatarURL: staffUser.displayAvatarURL({ dynamic: true }),
                    stats: stats,
                };
            } catch (error) {
                if (error.code === 10013) {
                    await console.log(`${color.yellow(`[WARNING]`)} Staff member with ID "${member.userId}" is unknown or invalid. They will not be displayed in the list.`);
                } else {
                    console.error(`Error processing staff member ${member.userId}:`, error);
                }
                return null;
            }
        }));
    
        // Filter out any null values (due to errors) from the array
        const validStaffMembers = staffWithStats.filter(member => member !== null);
    
        // Get the current logged-in user's member information
        const user = await guild.members.cache.get(req.user.id);
        const staffInfo = await staffModel.findOne({ userId: req.user.id });

        // Merge staffInfo into the user object
        if (staffInfo) {
            Object.assign(user, {
                roleName: staffInfo.roleName,
            });
        }

        res.render('staff', { config, existingStaffMembers: validStaffMembers, user, totalStaffMembers });
    } catch (error) {
        console.error("Error fetching staff members and statistics:", error);
        res.render('error', { config, errorMessage: "An error occurred while fetching staff members and statistics." });
    }
});


  
  app.post('/staff/add', isLoggedIn(), async (req, res) => {
    const { userIdOrUsername, roleName } = req.body;
    const guild = client.guilds.cache.get(config.GuildID);

    try {
        let userId;
        let user;

// Check if the input is a valid snowflake (user ID)
if (/^\d+$/.test(userIdOrUsername)) {
    userId = userIdOrUsername;

    // Check if the user ID corresponds to an existing user in the cache
    user = client.users.cache.get(userId);
    if (!user) throw new Error('Invalid user ID or username.');
} else {
    // If not a valid snowflake, try to find the user by username
    user = client.users.cache.find(user => user.username === userIdOrUsername);
    if (!user) throw new Error('Invalid user ID or username.');
    userId = user.id;
}

        const user2 = client.users.cache.get(userId);

        // Validate role name from config
        const roleConfig = config.staffRoles.find(role => role.name === roleName);
        if (!roleConfig) throw new Error('Invalid role name.');

        // Check if the user is already in the database
        const existingStaffMember = await staffModel.findOne({ userId });

        const hasPermissionToAdd = await utils.checkRolePriority(existingStaffMember, user, roleName, req.user);
        if (!hasPermissionToAdd) throw new Error("You don't have permission to manage this staff member!"); 

        if (existingStaffMember)  throw new Error('User is already a staff member.');

        // Add staff member to MongoDB
        await staffModel.create({ userId, roleName });

        // Give discord staff role if enabled
        const roleToGive = roleConfig.discordRoleToGive;
        if (roleToGive) {
            const role = guild.roles.cache.get(roleToGive);
            if (role) {
                const member = await guild.members.fetch(userId);
                member.roles.add(role);
            }
        }

        if(config.DashboardLogs) {
        // Log the staff addition
        const consoleLogMsg = `${color.yellow(`[DASHBOARD] ${color.cyan(`${req.user.username} (${req.user.id})`)} added ${color.cyan(user2.username)} (${user2.id}) as ${color.cyan(roleName)} staff member.`)}`;
        console.log(consoleLogMsg);

        const fileLogMsg = `\n[${new Date().toLocaleString()}] [DASHBOARD] ${req.user.username} (${req.user.id}) added ${user2.username} (${user2.id}) as ${roleName} staff member.`;
        fs.appendFile("./logs.txt", fileLogMsg + '\n', (error) => {
            if (error) console.error('Error logging staff addition event:', error);
        });
    }

        req.flash('success', 'Staff member added successfully.');
        res.redirect('/staff');
    } catch (error) {
        req.flash('error', error.message);
        //console.log(error)
        res.redirect('/staff');
    }
});

app.post('/staff/edit', isLoggedIn(), async (req, res) => {
    const { userIdToEdit, newRoleName } = req.body;
    const guild = client.guilds.cache.get(config.GuildID);

    try {
        // Find the staff member in the database
        const existingStaffMember = await staffModel.findOne({ userId: userIdToEdit });
        // If staff member doesn't exist, throw an error
        if (!existingStaffMember) throw new Error('User is not a staff member.');

        // Validate role name from config
        const roleConfig = config.staffRoles.find(role => role.name === newRoleName);
        if (!roleConfig) throw new Error('Invalid new role name.');

        const user = client.users.cache.get(userIdToEdit);
        if (!user) throw new Error('Invalid user');

        // Check permission to edit
        const hasPermissionToEdit = await utils.checkRolePriority(existingStaffMember, user, newRoleName, req.user);
        if (!hasPermissionToEdit) throw new Error("You don't have permission to manage this staff member!");

        // Update the role name
        existingStaffMember.roleName = newRoleName;
        await existingStaffMember.save();

        // Give or remove Discord role if enabled
        const roleToGive = roleConfig.discordRoleToGive;
        if (roleToGive) {
            const role = guild.roles.cache.get(roleToGive);
            if (role) {
                const member = await guild.members.fetch(userIdToEdit);
                member.roles.add(role);
            }
        }

        if (config.DashboardLogs) {
            // Log the staff edit
            const user = client.users.cache.get(userIdToEdit);
            const consoleLogMsg = `${color.yellow(`[DASHBOARD] ${color.cyan(`${req.user.username} (${req.user.id})`)} edited ${color.cyan(user.username)} (${userIdToEdit}) to ${color.cyan(newRoleName)} staff member.`)}`;
            console.log(consoleLogMsg);

            const fileLogMsg = `\n[${new Date().toLocaleString()}] [DASHBOARD] ${req.user.username} (${req.user.id}) edited ${user.username} (${userIdToEdit}) to ${newRoleName} staff member.`;
            fs.appendFile("./logs.txt", fileLogMsg + '\n', (error) => {
                if (error) console.error('Error logging staff edit event:', error);
            });
        }

        req.flash('success', 'Staff member edited successfully.');
        res.redirect('/staff');
    } catch (error) {
        req.flash('error', error.message);
        //console.log(error)
        res.redirect('/staff');
    }
});

app.post('/staff/remove', isLoggedIn(), async (req, res) => {
    const { userIdToRemove } = req.body;
    const guild = client.guilds.cache.get(config.GuildID);

    try {
        if (!userIdToRemove) throw new Error('User ID is required for removing a staff member.');

        const existingStaffMember = await staffModel.findOne({ userId: userIdToRemove });
        const hasPermissionToRemove = await utils.checkRolePriority(existingStaffMember, userIdToRemove, existingStaffMember.roleName, req.user);
        if (!hasPermissionToRemove) throw new Error("You don't have permission to manage this staff member!"); 

        const roleConfig = config.staffRoles.find(role => role.name.toLowerCase() === existingStaffMember.roleName.toLowerCase());
        if (!roleConfig) throw new Error('Invalid role name.');

        let oldStaffRole = existingStaffMember.roleName

        const result = await staffModel.deleteOne({ userId: userIdToRemove });

        if (result.deletedCount === 1) {
            req.flash('success', 'Staff member removed successfully.');

            if(config.DashboardLogs) {
        // Log the staff removal
        const consoleLogMsg = `${color.yellow(`[DASHBOARD] ${color.cyan(`${req.user.username} (${req.user.id})`)} removed ${color.cyan(existingStaffMember.userId)} from staff members.`)}`;
        console.log(consoleLogMsg);

        const fileLogMsg = `\n[${new Date().toLocaleString()}] [DASHBOARD] ${req.user.username} (${req.user.id}) removed ${existingStaffMember.userId} from staff members.`;
        fs.appendFile("./logs.txt", fileLogMsg + '\n', (error) => {
            if (error) console.error('Error logging staff removal event:', error);
        });
    }

                    // Automatically remove the role specified in roleToGive
                    const currentStaffRole = config.staffRoles.find(r => r.name.toLowerCase() === oldStaffRole.toLowerCase());
                    const oldRoleToRemove = currentStaffRole ? currentStaffRole.discordRoleToGive : '';
                    if (oldRoleToRemove) {
                        const role = guild.roles.cache.get(oldRoleToRemove);
                        if (role) {
                            const member = await guild.members.fetch(userIdToRemove);
                            member.roles.remove(role);
                        }
                    }
            
        } else {
            req.flash('error', 'User is not a staff member or could not be removed.');
        }

        res.redirect('/staff');
    } catch (error) {
        req.flash('error', error.message);
        //console.log(error)
        res.redirect('/staff');
    }
});


app.get('/verify', async (req, res) => {
    const { token } = req.query;

    // Check if token exists in the request query
    if (!token) return res.status(400).send('Verification token is required');

    // Fetch the user based on the verification token
    const user = await userModel.findOne({ verificationToken: token });
    if (!user) return res.status(400).send('Invalid verification token');

    res.render('captcha-verification', { user, config });
});

const hCaptcha = require('hcaptcha');
// Handle the CAPTCHA form submission
app.post('/verify', async (req, res) => {
    const { token, 'h-captcha-response': hCaptchaResponse } = req.body;

    try {
        // Log hCaptcha response for troubleshooting
        // console.log('hCaptcha Response:', hCaptchaResponse);

        // Verify hCaptcha response
        const apiKey = config.VerificationSettings.hCaptchaSiteKey;

        const hCaptchaVerificationResponse = await verifyHCaptcha(apiKey, hCaptchaResponse);

        // Log hCaptcha verification response for troubleshooting
        // console.log('hCaptcha Verification Response:', hCaptchaVerificationResponse);

        if (!hCaptchaVerificationResponse.success) {
            console.error('Invalid hCaptcha verification:', hCaptchaVerificationResponse);
            req.flash('error', 'Invalid hCaptcha verification');
        }

        // Fetch the user based on the verification token
        const user = await userModel.findOne({ verificationToken: token });

        if (!user) {
            console.error('Invalid verification token:', token);
            req.flash('error', 'Invalid verification token');
        }

        const guild = client.guilds.cache.get(config.GuildID);
        const member = guild.members.cache.get(user.userID);

        if (member) {
            const verifiedRoleIDs = config.VerificationSettings.VerifiedRoleID;

            // Add verified roles
            await Promise.all(verifiedRoleIDs.map(async (roleId) => {
                const role = guild.roles.cache.get(roleId);
                if (role) await member.roles.add(role);
                else console.log('\x1b[31m%s\x1b[0m', `[ERROR] VerifiedRoleID ${roleId} is not a valid role!`);
            }));

            req.flash('success', `${config.VerificationMessages.successVerify}`);
        }

        res.render('captcha-verification', { user: {}, config, messages: req.flash() });
        // Clean up: remove the verification token from the user model
        await userModel.findOneAndUpdate({ userID: user.discordId }, { $unset: { verificationToken: '' } });
    } catch (error) {
        console.error('Error during hCaptcha verification:', error);
        res.status(500).send('Internal Server Error');
    }
});

// Function to verify hCaptcha using hcaptcha npm package
async function verifyHCaptcha(apiKey, hCaptchaResponse) {
    try {
        const verificationResponse = await hCaptcha.verify(config.VerificationSettings.hCaptchaSecretKey, hCaptchaResponse);
        return verificationResponse;
    } catch (error) {
        throw error;
    }
}



app.get('/view/:userId', isLoggedIn(['VIEW_RECENT_MESSAGES', 'VIEW_HISTORY', 'DELETE_PUNISHMENTS', 'CLEAR_RECENT_MESSAGES', 'CLEAR_HISTORY', 'MANAGE_STAFF_MEMBERS']), async (req, res) => {
    const userId = req.params.userId;
    const guild = client.guilds.cache.get(config.GuildID);

    if(config.DashboardLogs) {
        // Log the viewing page event to the console
        const consoleLogMsg = `${color.yellow(`[DASHBOARD] ${color.cyan(`${req.user.username} (${req.user.id})`)} accessed ${color.cyan(`/view/${userId}`)} page`)}`;
        console.log(consoleLogMsg);
    
        // Log the viewing page event to a file
        const fileLogMsg = `\n[${new Date().toLocaleString()}] [DASHBOARD] ${req.user.username} (${req.user.id}) accessed /view/${userId} page`;
        fs.appendFile("./logs.txt", fileLogMsg + '\n', (error) => {
          if (error) console.error('Error logging event:', error);
        });
    }

    try {

        const hasPermission = await utils.checkPermission(req.user.id, "VIEW_USERS");
        if(!hasPermission) return res.render('error', { config, errorMessage: `You don't have enough permissions to access this page!` });

        // Fetch user information from Discord API
        const user2 = await guild.members.fetch(userId);
        const fullUser = await client.users.fetch(userId, { force: true });

        // Retrieve additional user information (e.g., profile picture, username)
        const profilePicture = user2.displayAvatarURL({ format: 'png', size: 512 });
        const profileBanner = fullUser.bannerURL({ format: 'png', dynamic: true, size: 1024 });
        const username = user2.user.username;
        const globalName = fullUser.globalName

        const user = await guild.members.cache.get(req.user.id);
        const userFromDB = await userModel.findOne({ userID: userId });
        const punishments = await punishmentModel.find({ userID: userId }).sort({ date: -1 });

        const isStaff = await staffModel.findOne({ userId: userId });
        const isSameUser = req.user.id === user2.user.id

        // Fetch staff member's username
        const fetchStaffUsernames = async () => {
            const usernames = {};
            await Promise.all(
                punishments.map(async (punishment) => {
                    try {
                        const staffUser = await client.users.fetch(punishment.staff);
                        usernames[punishment.staff] = staffUser.username;
                    } catch (error) {
                        //console.error('Error fetching staff username:', error);
                        usernames[punishment.staff] = 'Unknown';
                    }
                })
            );
            return usernames;
        };

        const staffUsernames = await fetchStaffUsernames();

        function getRelativeTime(date) {
            const currentDate = new Date();
            const targetDate = new Date(date);
            const timeDifference = currentDate.getTime() - targetDate.getTime();
        
            const seconds = Math.floor(timeDifference / 1000);
            const minutes = Math.floor(seconds / 60);
            const hours = Math.floor(minutes / 60);
            const days = Math.floor(hours / 24);
        
            if (days > 0) {
                return days === 1 ? '1 day ago' : `${days} days ago`;
            } else if (hours > 0) {
                return hours === 1 ? '1 hour ago' : `${hours} hours ago`;
            } else if (minutes > 0) {
                return minutes === 1 ? '1 minute ago' : `${minutes} minutes ago`;
            } else {
                return seconds <= 20 ? 'just now' : `${seconds} seconds ago`;
            }
        }

        function getFileExtension(url) {
            // Extract the file extension from the URL
            const fileExtensionMatch = url.match(/\.([0-9a-z]+)(?:[?#]|$)/i);
        
            if (fileExtensionMatch) {
                // If a file extension is found, return it
                return fileExtensionMatch[1];
            } else {
                // If no file extension is found, return an empty string
                return "";
            }
        }

        const totalKicks = punishments.filter(type => type.punishment === 'Kick').length;
        const totalBans = punishments.filter(type => type.punishment === 'Ban').length;
        const totalWarns = punishments.filter(type => type.punishment === 'Warn').length;
        const totalTimeouts = punishments.filter(type => type.punishment === 'Timeout').length;

        res.render('view', { profilePicture, profileBanner, username, config, user, user2, userId, userFromDB, isStaff, punishments, getRelativeTime, staffUsernames, getFileExtension, globalName, totalWarns, totalBans, totalKicks, totalTimeouts, permissions: res.locals.permissions, isSameUser });
    } catch (error) {
        if (error.name === 'DiscordAPIError[50035]' && error.status === 400 && error.code === 50035 || error.name === 'DiscordAPIError[10013]' && error.status === 404 && error.code === 10013) {
            return res.render('error', { config, errorMessage: 'Invalid member, or the member is not in the server.' });
        } else {
            console.error('Error fetching user information:', error);
            res.render('error', { config, errorMessage: 'An error occurred.' });
        }
    }
});


app.post('/delete-punishment', isLoggedIn(), async (req, res) => {
    const { punishmentID } = req.body;

    const hasPermission = await utils.checkPermission(req.user.id, "DELETE_PUNISHMENTS");

    if(hasPermission && punishmentID) try {
        // Find the punishment document by punishmentID and delete it
        const deletedPunishment = await punishmentModel.findOneAndDelete({ punishmentID });
        
        if (!deletedPunishment) return res.status(404).json({ success: false, message: 'Punishment not found' });

        if(config.DashboardLogs) {
            // Log the deletion of punishment
            const consoleLogMsg = `${color.yellow(`[DASHBOARD] ${color.cyan(`${req.user.username} (${req.user.id})`)} deleted punishment with ID ${color.cyan(punishmentID)}.`)}`;
            console.log(consoleLogMsg);

            const fileLogMsg = `\n[${new Date().toLocaleString()}] [DASHBOARD] ${req.user.username} (${req.user.id}) deleted punishment with ID ${punishmentID}.`;
            fs.appendFile("./logs.txt", fileLogMsg + '\n', (error) => {
                if (error) console.error('Error logging punishment deletion event:', error);
            });
        }

        res.json({ success: true, message: `Punishment with ID ${punishmentID} has been deleted successfully.` });
    } catch (error) {
        console.error('Error deleting punishment:', error);
        res.status(500).json({ success: false, message: 'Internal server error' });
    }
});


app.post('/clear-history', isLoggedIn(), async (req, res) => {
    const userId = req.body.userId; 

    const hasPermission = await utils.checkPermission(req.user.id, "CLEAR_HISTORY");

    if(hasPermission && userId) try {
        // Delete all documents with the provided userID
        await punishmentModel.deleteMany({ userID: userId });

        if(config.DashboardLogs) {
            // Log the clearing of punishment history
            const consoleLogMsg = `${color.yellow(`[DASHBOARD] ${color.cyan(`${req.user.username} (${req.user.id})`)} cleared punishment history for user with ID ${color.cyan(userId)}.`)}`;
            console.log(consoleLogMsg);

            const fileLogMsg = `\n[${new Date().toLocaleString()}] [DASHBOARD] ${req.user.username} (${req.user.id}) cleared punishment history for user with ID ${userId}.`;
            fs.appendFile("./logs.txt", fileLogMsg + '\n', (error) => {
                if (error) console.error('Error logging punishment history clearance event:', error);
            });
        }

        res.status(200).send({ message: 'Punishment history cleared successfully' });
    } catch (error) {
        res.status(500).send({ error: 'Internal server error' });
    }
});

// Route to clear recent messages
app.post('/clear-messages', isLoggedIn(), async (req, res) => {
    const userId = req.body.userId; 

    const hasPermission = await utils.checkPermission(req.user.id, "CLEAR_RECENT_MESSAGES");

   if(hasPermission && userId) try {
        await userModel.findOneAndUpdate({ userID: userId }, { $set: { messageHistory: [] } });

        if(config.DashboardLogs) {
            // Log the clearing of recent messages
            const consoleLogMsg = `${color.yellow(`[DASHBOARD] ${color.cyan(`${req.user.username} (${req.user.id})`)} cleared recent messages for user with ID ${color.cyan(userId)}.`)}`;
            console.log(consoleLogMsg);

            const fileLogMsg = `\n[${new Date().toLocaleString()}] [DASHBOARD] ${req.user.username} (${req.user.id}) cleared recent messages for user with ID ${userId}.`;
            fs.appendFile("./logs.txt", fileLogMsg + '\n', (error) => {
                if (error) console.error('Error logging recent messages clearance event:', error);
            });
        }

        res.status(200).send({ message: 'Recent messages cleared successfully' });
    } catch (error) {
        res.status(500).send({ error: 'Internal server error' });
    }
});

// Page to view all appeals
app.get('/appeals', isLoggedIn(['VIEW_APPEALS', 'MANAGE_APPEALS', 'DELETE_APPEALS']), async (req, res) => {
    const guild = client.guilds.cache.get(config.GuildID);

    const hasPermission = await utils.checkPermission(req.user.id, "VIEW_APPEALS");
    if(!hasPermission) return res.render('error', { config, errorMessage: `You don't have enough permissions to access this page!` });

    if(config.DashboardLogs) {
        // Log the viewing page event to the console
        const consoleLogMsg = `${color.yellow(`[DASHBOARD] ${color.cyan(`${req.user.username} (${req.user.id})`)} accessed ${color.cyan(`/appeals`)} page`)}`;
        console.log(consoleLogMsg);
    
        // Log the viewing page event to a file
        const fileLogMsg = `\n[${new Date().toLocaleString()}] [DASHBOARD] ${req.user.username} (${req.user.id}) accessed /appeals page`;
        fs.appendFile("./logs.txt", fileLogMsg + '\n', (error) => {
          if (error) console.error('Error logging event:', error);
        });
    }

    try {
        const appeals = await appealModel.find();

        // Fetch user information for each appeal
        for (const appeal of appeals) {
            try {
                const user = await client.users.fetch(appeal.userId);
                appeal.username = user.username;
                appeal.avatarURL = user.avatarURL({ format: 'png', size: 256 }) || 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/fd/Faenza-avatar-default-symbolic.svg/2048px-Faenza-avatar-default-symbolic.svg.png';
            } catch (error) {
                //console.error(`Error fetching user for appeal with ID ${appeal._id}: ${error.message}`);
                appeal.username = appeal.username || 'Unknown User';
                appeal.avatarURL = 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/fd/Faenza-avatar-default-symbolic.svg/2048px-Faenza-avatar-default-symbolic.svg.png';
            }
        }

    // Get the current logged-in user's member information
    const user = await guild.members.cache.get(req.user.id);
    const staffInfo = await staffModel.findOne({ userId: req.user.id });
    
    // Merge staffInfo into the user object
    if (staffInfo) {
        Object.assign(user, {
            roleName: staffInfo.roleName,
        });
    }

    function getRelativeTime(date) {
        const currentDate = new Date();
        const targetDate = new Date(date);
        const timeDifference = currentDate.getTime() - targetDate.getTime();
    
        const seconds = Math.floor(timeDifference / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);
        const days = Math.floor(hours / 24);
    
        if (days > 0) {
            return days === 1 ? '1 day ago' : `${days} days ago`;
        } else if (hours > 0) {
            return hours === 1 ? '1 hour ago' : `${hours} hours ago`;
        } else if (minutes > 0) {
            return minutes === 1 ? '1 minute ago' : `${minutes} minutes ago`;
        } else {
            return seconds <= 20 ? 'just now' : `${seconds} seconds ago`;
        }
    }

        res.render('appeals', { appeals, user, guild, config, getRelativeTime, permissions: res.locals.permissions });
    } catch (err) {
        console.error(err);
        res.status(500).send('Internal Server Error');
    }
});

app.get('/view-appeal/:id', isLoggedIn(['VIEW_APPEALS', 'MANAGE_APPEALS', 'DELETE_APPEALS']), async (req, res) => {
    const { id } = req.params;
    const guild = client.guilds.cache.get(config.GuildID);

    const hasPermission = await utils.checkPermission(req.user.id, "VIEW_APPEALS");
    if(!hasPermission) return res.render('error', { config, errorMessage: `You don't have enough permissions to access this page!` });

    if(config.DashboardLogs) {
        // Log the viewing page event to the console
        const consoleLogMsg = `${color.yellow(`[DASHBOARD] ${color.cyan(`${req.user.username} (${req.user.id})`)} accessed ${color.cyan(`/view-appeal/${id}`)} page`)}`;
        console.log(consoleLogMsg);
    
        // Log the viewing page event to a file
        const fileLogMsg = `\n[${new Date().toLocaleString()}] [DASHBOARD] ${req.user.username} (${req.user.id}) accessed /view-appeal/${id} page`;
        fs.appendFile("./logs.txt", fileLogMsg + '\n', (error) => {
          if (error) console.error('Error logging event:', error);
        });
    }

    try {
        const appeal = await appealModel.findOne({ appealID: id });
        if(!appeal) return res.render('error', { config, errorMessage: `An appeal with that ID does not exist!` });

        const punishments = await punishmentModel.find({ userID: appeal.userId }).sort({ date: -1 });
        const punishment = await punishmentModel.findOne({ punishmentID: appeal.punishmentId });
        if(!punishment) return res.render('error', { config, errorMessage: `A punishment for that appeal does not exist!` });

        // Fetch staff member's username
        const fetchStaffUsernames = async () => {
            const usernames = {};
            await Promise.all(
                punishments.map(async (punishment) => {
                    try {
                        const staffUser = await client.users.fetch(punishment.staff);
                        usernames[punishment.staff] = staffUser.username;
                    } catch (error) {
                        //console.error('Error fetching staff username:', error);
                        usernames[punishment.staff] = 'Unknown';
                    }
                })
            );
            return usernames;
        };

        const staffUsernames = await fetchStaffUsernames();

        // Check if the user is in the server
        try {
            const member = await guild.members.fetch(appeal.userId);
            appeal.userInServer = member ? 'The user is in the server' : 'The user is not in the server';
        } catch (error) {
            appeal.userInServer = 'The user is not in the server';
        }

        // if appeal is accepted or denied, get username from decisionUserID
        if(appeal.status !== "Pending") try {
            const user = await client.users.fetch(appeal.decisionUserID);
            appeal.decisionUser = user.username
        } catch (error) {
            appeal.decisionUser = 'Unknown User';
        }


        // Fetch user information for the appeal
        try {
            const user = await client.users.fetch(appeal.userId);
            appeal.username = user.username;
            appeal.avatarURL = user.avatarURL({ format: 'png', size: 256 }) || 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/fd/Faenza-avatar-default-symbolic.svg/2048px-Faenza-avatar-default-symbolic.svg.png';
        } catch (error) {
            //console.error(`Error fetching user for appeal with ID ${appeal._id}: ${error.message}`);
            appeal.username = appeal.username || 'Unknown User';
            appeal.avatarURL = 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/fd/Faenza-avatar-default-symbolic.svg/2048px-Faenza-avatar-default-symbolic.svg.png';
        }

        try {
            const user = await client.users.fetch(punishment.staff);
            punishment.staff = user.username;
        } catch (error) {
            //console.error(`Error fetching user for appeal with ID ${appeal._id}: ${error.message}`);
            punishment.staff = 'Unknown User';
        }

    // Get the current logged-in user's member information
    const user = await guild.members.cache.get(req.user.id);
    const staffInfo = await staffModel.findOne({ userId: req.user.id });
    
    // Merge staffInfo into the user object
    if (staffInfo) {
        Object.assign(user, {
            roleName: staffInfo.roleName,
        });
    }

    function getRelativeTime(date) {
        const currentDate = new Date();
        const targetDate = new Date(date);
        const timeDifference = currentDate.getTime() - targetDate.getTime();
    
        const seconds = Math.floor(timeDifference / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);
        const days = Math.floor(hours / 24);
    
        if (days > 0) {
            return days === 1 ? '1 day ago' : `${days} days ago`;
        } else if (hours > 0) {
            return hours === 1 ? '1 hour ago' : `${hours} hours ago`;
        } else if (minutes > 0) {
            return minutes === 1 ? '1 minute ago' : `${minutes} minutes ago`;
        } else {
            return seconds <= 20 ? 'just now' : `${seconds} seconds ago`;
        }
    }

    function getFileExtension(url) {
        // Extract the file extension from the URL
        const fileExtensionMatch = url.match(/\.([0-9a-z]+)(?:[?#]|$)/i);
    
        if (fileExtensionMatch) {
            // If a file extension is found, return it
            return fileExtensionMatch[1];
        } else {
            // If no file extension is found, return an empty string
            return "";
        }
    }

        res.render('view-appeal', { punishment, getFileExtension, punishments, staffUsernames, appeal, user, guild, config, getRelativeTime, permissions: res.locals.permissions });
    } catch (err) {
        console.error(err);
        res.status(500).send('Internal Server Error');
    }
});


app.post('/acceptAppeal', isLoggedIn(), async (req, res) => {
    const guild = client.guilds.cache.get(config.GuildID);


    const hasPermission = await utils.checkPermission(req.user.id, "MANAGE_APPEALS");

    if(hasPermission) try {
        const { appealId, reason } = req.body;
        const appeal = await appealModel.findOne({ appealID: appealId });
        const punishment = await punishmentModel.findOne({ punishmentID: appeal.punishmentId });
        if(!appeal || !punishment) return res.render('error', { config, errorMessage: `Punishment not found` });
        if(appeal.status !== "Pending") return res.render('error', { config, errorMessage: `This appeal has already been denied or accepted!` });

        const punishmentType = appeal.punishmentType

        // Lift punishment from user
        if(punishmentType === "Timeout") {
            try {
                const member = await guild.members.fetch(appeal.userId);
                if (member && member?.communicationDisabledUntil) member.timeout(null, `Punishment appeal accepted by: ${req.user.username}`);

            } catch (error) {
            }

        } else if(punishmentType === "Ban") {
            const bans = await guild.bans.fetch();
            if (bans && bans.has(appeal.userId)) {
                await guild.members.unban(appeal.userId, `Punishment appeal accepted by: ${req.user.username}`);
            }
        }

        punishment.appealID = appeal.punishmentId;
        punishment.status = 'Appealed';
        await punishment.save()

        appeal.status = 'Accepted';
        appeal.decisionReason = reason || 'No reason provided';
        appeal.decisionUserID = req.user.id;
        await appeal.save();

        if(config.DashboardLogs) {
            // Log the acceptance of the appeal
            const consoleLogMsg = `${color.yellow(`[DASHBOARD] ${color.cyan(`${req.user.username} (${req.user.id})`)} accepted appeal ${color.cyan(appealId)}.`)}`;
            console.log(consoleLogMsg);

            const fileLogMsg = `\n[${new Date().toLocaleString()}] [DASHBOARD] ${req.user.username} (${req.user.id}) accepted appeal ${appealId}.`;
            fs.appendFile("./logs.txt", fileLogMsg + '\n', (error) => {
                if (error) console.error('Error logging appeal acceptance event:', error);
            });
        }

        res.status(200).json({ message: 'Appeal accepted successfully' });
       //res.redirect('/appeal');
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.post('/denyAppeal', isLoggedIn(), async (req, res) => {

    const hasPermission = await utils.checkPermission(req.user.id, "MANAGE_APPEALS");

    if(hasPermission) try {
        const { appealId, reason } = req.body;
        const appeal = await appealModel.findOne({ appealID: appealId });
        const punishment = await punishmentModel.findOne({ punishmentID: appeal.punishmentId });
        if(!appeal || !punishment) return res.render('error', { config, errorMessage: `Punishment not found` });
        if(appeal.status !== "Pending") return res.render('error', { config, errorMessage: `This appeal has already been denied or accepted!` });

        appeal.status = 'Denied';
        appeal.decisionReason = reason || 'No reason provided';
        appeal.decisionUserID = req.user.id;
        await appeal.save();

        if(config.DashboardLogs) {
            // Log the denial of the appeal
            const consoleLogMsg = `${color.yellow(`[DASHBOARD] ${color.cyan(`${req.user.username} (${req.user.id})`)} denied appeal ${color.cyan(appealId)}.`)}`;
            console.log(consoleLogMsg);

            const fileLogMsg = `\n[${new Date().toLocaleString()}] [DASHBOARD] ${req.user.username} (${req.user.id}) denied appeal ${appealId}.`;
            fs.appendFile("./logs.txt", fileLogMsg + '\n', (error) => {
                if (error) console.error('Error logging appeal denial event:', error);
            });
        }

        res.status(200).json({ message: 'Appeal denied successfully' });
       //res.redirect('/appeal');
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.post('/deleteAppeal', isLoggedIn(), async (req, res) => {

    const hasPermission = await utils.checkPermission(req.user.id, "DELETE_APPEALS");

    if(hasPermission) try {
        const { appealId } = req.body;
        const appeal = await appealModel.findOne({ appealID: appealId });
        if(!appeal) return res.render('error', { config, errorMessage: `Punishment not found` });
        if(appeal.status !== "Pending") return res.render('error', { config, errorMessage: `This appeal has already been denied or accepted!` });

        const deletedAppeal = await appealModel.deleteOne({ appealID: appealId });

        if (deletedAppeal.deletedCount === 1) {

            if(config.DashboardLogs) {
                // Log the deletion of the appeal
                const consoleLogMsg = `${color.yellow(`[DASHBOARD] ${color.cyan(`${req.user.username} (${req.user.id})`)} deleted appeal ${color.cyan(appealId)}.`)}`;
                console.log(consoleLogMsg);

                const fileLogMsg = `\n[${new Date().toLocaleString()}] [DASHBOARD] ${req.user.username} (${req.user.id}) deleted appeal ${appealId}.`;
                fs.appendFile("./logs.txt", fileLogMsg + '\n', (error) => {
                    if (error) console.error('Error logging appeal deletion event:', error);
                });
            }

            res.status(200).json({ message: 'Appeal deleted successfully' });
        } else {
            return res.render('error', { config, errorMessage: `Appeal not found` });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.get('/appeal', requireLogin, async (req, res) => {
    const guild = client.guilds.cache.get(config.GuildID);
    const user = await client.users.fetch(req.user.id);

    const appeals = await appealModel.find({ userId: req.user.id }).sort({ submissionDate: -1 }).exec();

    let punishment = null;

    res.render('appealForm', { punishment, appeals, user, guild, config, successMessages: req.flash('success') });
});

app.get('/appeal/:punishmentId', requireLogin, async (req, res) => {
    const guild = client.guilds.cache.get(config.GuildID);
    const user = await client.users.fetch(req.user.id);

    try {
        const { punishmentId } = req.params;
        const punishment = await punishmentModel.findOne({ punishmentID: punishmentId });

        if (!punishment || req.user.id !== punishment?.userID) return res.redirect(`/appeal`);
        if(punishment && punishment.punishment === "Warn" && config.Warn.Appealable === false) return res.redirect(`/appeal`);
        if(punishment && punishment.punishment === "Timeout" && config.Timeout.Appealable === false) return res.redirect(`/appeal`);
        if(punishment && punishment.punishment === "Kick" && config.Kick.Appealable === false) return res.redirect(`/appeal`);
        if(punishment && punishment.punishment === "Ban" && config.Ban.Appealable === false) return res.redirect(`/appeal`);


        // Render the appeal form with the punishment data
        res.render('appealForm', { user, guild, config, successMessages: req.flash('success'), punishment });
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
});

app.post('/findPunishment', requireLogin, async (req, res) => {
    try {
        const { punishmentId } = req.body;
        const cooldown = await Cooldown.findOne({ userId: req.user.id });
        const punishment = await punishmentModel.findOne({ punishmentID: punishmentId });

        const existingAppeal = await appealModel.findOne({ punishmentId, status: 'Pending' });
        if (existingAppeal) {
            req.flash('error', 'There is already an active appeal for this punishment.');
            return res.redirect('/appeal');
        }

        if (!punishment || req.user.id !== punishment?.userID) {
            req.flash('error', 'Invalid Punishment ID');
            return res.redirect('/appeal');
        }

        if (cooldown && cooldown.cooldownUntil > Date.now()) {
            req.flash('error', 'You are currently on cooldown for submitting appeals.');
            return res.redirect('/appeal');
        }

        if(punishment && punishment.punishment === "Warn" && config.Warn.Appealable === false) {
            req.flash('error', `You can't appeal warnings!`);
            return res.redirect('/appeal');
        }

        if(punishment && punishment.punishment === "Timeout" && config.Timeout.Appealable === false) {
            req.flash('error', `You can't appeal timeouts!`);
            return res.redirect('/appeal');
        }
    
        if(punishment && punishment.punishment === "Kick" && config.Kick.Appealable === false) {
            req.flash('error', `You can't appeal kicks!`);
            return res.redirect('/appeal');
        }

        if(punishment && punishment.punishment === "Ban" && config.Ban.Appealable === false) {
            req.flash('error', `You can't appeal bans!`);
            return res.redirect('/appeal');
        }

        // Punishment found, redirect with punishment ID in the URL
        res.redirect(`/appeal/${punishmentId}`);
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
});

app.post('/submitAppeal', requireLogin, async (req, res) => {
    try {
        // Check if the user has a cooldown
        const cooldown = await Cooldown.findOne({ userId: req.user.id });
        const { userId, punishmentId, answers } = req.body;

        const punishment = await punishmentModel.findOne({ punishmentID: punishmentId });
        if (!punishment || req.user.id !== punishment?.userID) {
            req.flash('error', 'Invalid Punishment');
            return res.redirect('/appeal');
        }

        const existingAppeal = await appealModel.findOne({ punishmentId, status: 'Pending' });
        if (existingAppeal) {
            req.flash('error', 'There is already an active appeal for this punishment.');
            return res.redirect('/appeal');
        }

        if (cooldown && cooldown.cooldownUntil > Date.now()) {
            req.flash('error', 'You are currently on cooldown for submitting appeals.');
            return res.redirect('/appeal');
        }

        // Generate a unique ID for the appeal
        const uniqueID = Date.now().toString().slice(-6) + Math.floor(Math.random() * 1000000).toString().padStart(6, '0');

        // Save the appeal to MongoDB
        const appeal = new appealModel({
            userId,
            punishmentId,
            answers,
            submissionDate: Date.now(),
            punishmentType: punishment.punishment,
            staffID: punishment.staff,
            username: req.user.username,
            appealID: uniqueID,
        });
        await appeal.save();

        // Add or update user cooldown
        const cooldownDuration = config.AppealSystem.cooldown * 60 * 60 * 1000;
        const cooldownUntil = new Date(Date.now() + cooldownDuration);
        await Cooldown.findOneAndUpdate({ userId: req.user.id }, { cooldownUntil }, { upsert: true });

        req.flash('success', `Your appeal has been submitted successfully! You will be able to view the status of your appeal(s) at ${config.Dashboard.URL}/appeal`);

        // Redirect back to the appeal form page
        res.redirect('/appeal');
    } catch (error) {
        console.error('Error processing appeal:', error);
        req.flash('error', 'An error occurred while processing your appeal.');
        res.redirect('/appeal');
    }
});

app.get('/overview', isLoggedIn(), async (req, res) => {
    const guild = client.guilds.cache.get(config.GuildID);

    const hasPermission = await utils.checkPermission(req.user.id, "OVERVIEW_MESSAGES");
    if(!hasPermission) return res.render('error', { config, errorMessage: `You don't have enough permissions to access this page!` });

    // Get the current logged-in user's member information
    const user = await guild.members.cache.get(req.user.id);
    const staffInfo = await staffModel.findOne({ userId: req.user.id });
    
    // Merge staffInfo into the user object
    if (staffInfo) {
        Object.assign(user, {
            roleName: staffInfo.roleName,
        });
    }

    if(config.DashboardLogs) {
        // Log the viewing page event to the console
        const consoleLogMsg = `${color.yellow(`[DASHBOARD] ${color.cyan(`${req.user.username} (${req.user.id})`)} accessed ${color.cyan('/overview')} page`)}`;
        console.log(consoleLogMsg);
    
        // Log the viewing page event to a file
        const fileLogMsg = `\n[${new Date().toLocaleString()}] [DASHBOARD] ${req.user.username} (${req.user.id}) accessed /overview page`;
        fs.appendFile("./logs.txt", fileLogMsg + '\n', (error) => {
          if (error) console.error('Error logging event:', error);
        });
    }

    res.render('overview', { user, config, successMessages: req.flash('success') });
});

app.get('/overview/messages', isLoggedIn(), async (req, res) => {
    try {
        const guildDB = await guildModel.findOne({ guildID: config.GuildID });
    
        const hasPermission = await utils.checkPermission(req.user.id, "OVERVIEW_MESSAGES");
        if(!hasPermission) return res.render('error', { config, errorMessage: `You don't have enough permissions to access this page!` });

        if (guildDB && guildDB.recentMessages) {
            const messages = guildDB.recentMessages;
    
            // Fetch user information for each message
            const messagesWithUserInfo = await Promise.all(messages.map(async (message) => {
                try {
                    const user = await client.users.fetch(message.userID);
            
                    // Create a new object with message properties and user information
                    const messageWithUserInfo = {
                        guildID: config.GuildID,
                        channelName: message.channelName,
                        channelID: message.channelID,
                        msgID: message.msgID,
                        message: message.message,
                        userID: message.userID,
                        timestamp: message.timestamp,
                        username: user.username,
                        avatarURL: user.avatarURL({ format: 'png', size: 256 }) || 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/fd/Faenza-avatar-default-symbolic.svg/2048px-Faenza-avatar-default-symbolic.svg.png'
                    };
            
                    // Return the new message object
                    return messageWithUserInfo;
                } catch (error) {
                    //console.error("Error fetching user:", error);
                    // Assign default values if there's an error
                    const messageWithUserInfo = {
                        guildID: config.GuildID,
                        channelName: message.channelName,
                        channelID: message.channelID,
                        msgID: message.msgID,
                        message: message.message,
                        userID: message.userID,
                        timestamp: message.timestamp,
                        username: 'Unknown User',
                        avatarURL: 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/fd/Faenza-avatar-default-symbolic.svg/2048px-Faenza-avatar-default-symbolic.svg.png'
                    };
                    
                    // Return the new message object with default values
                    return messageWithUserInfo;
                }
            }));
            
            // Send the response with messagesWithUserInfo array
            await res.json(messagesWithUserInfo);
            
        } else {
            res.status(404).json({ error: 'No messages found' });
        }
    } catch (error) {
        console.error("Error fetching guildDB:", error);
        res.status(500).json({ error: 'An error occurred while fetching messages' });
    }
});

app.post('/overview/messages/delete', isLoggedIn(), async (req, res) => {
    const { msgID, channelID } = req.body;

    const hasPermission = await utils.checkPermission(req.user.id, "OVERVIEW_MESSAGES");
    if(!hasPermission) return res.render('error', { config, errorMessage: `You don't have enough permissions to access this page!` });

    if (msgID && channelID) try {
            // Fetch the channel and delete the message from Discord
            const channel = await client.channels.fetch(channelID);

            if (channel) {
                const message = await channel.messages.fetch(msgID);

                if (message) {
                    await message.delete();
                    console.log(`Deleted message with ID ${msgID} from Discord.`);
                } else {
                    console.error(`Message with ID ${msgID} not found in Discord. (/overview/messages/delete)`);
                }
            } else {
                console.error('Channel not found or is not a text channel. (/overview/messages/delete)');
            }

            res.json({ success: true });
        } catch (error) {
            //console.error('Error deleting message (/overview/messages/delete):', error);
            res.json({ success: false });
    } else {
        res.json({ success: false, message: 'Message not found in database.' });
    }
});



app.get('/punishment/lookup', isLoggedIn(), async (req, res) => {
    const guild = client.guilds.cache.get(config.GuildID);

    const hasPermission = await utils.checkPermission(req.user.id, "LOOKUP_PUNISHMENTS");
    if(!hasPermission) return res.render('error', { config, errorMessage: `You don't have enough permissions to access this page!` });

    let punishment = null;

    // Get the current logged-in user's member information
    const user = await guild.members.cache.get(req.user.id);
    const staffInfo = await staffModel.findOne({ userId: req.user.id });
    
    // Merge staffInfo into the user object
    if (staffInfo) {
        Object.assign(user, {
            roleName: staffInfo.roleName,
        });
    }

    res.render('punishmentLookup', { user, config, punishment, successMessages: req.flash('success') });
});

app.get('/punishment/lookup/:punishmentId', isLoggedIn(['LOOKUP_PUNISHMENTS', 'DELETE_PUNISHMENTS']), async (req, res) => {
    const guild = client.guilds.cache.get(config.GuildID);

    const hasPermission = await utils.checkPermission(req.user.id, "LOOKUP_PUNISHMENTS");
    if(!hasPermission) return res.render('error', { config, errorMessage: `You don't have enough permissions to access this page!` });

    try {
        const { punishmentId } = req.params;
        const punishment = await punishmentModel.findOne({ punishmentID: punishmentId });
        if (!punishment) return res.redirect(`/punishment/lookup`);

        const existingAppeal = await appealModel.findOne({ punishmentId, status: 'Pending' });

        // Fetch user information for the appeal
        try {
            const user = await client.users.fetch(punishment.userID);
            punishment.username = user.username;
            punishment.avatarURL = user.avatarURL({ format: 'png', size: 256 }) || 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/fd/Faenza-avatar-default-symbolic.svg/2048px-Faenza-avatar-default-symbolic.svg.png';
        } catch (error) {
            punishment.username = punishment.username || 'Unknown User';
            punishment.avatarURL = 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/fd/Faenza-avatar-default-symbolic.svg/2048px-Faenza-avatar-default-symbolic.svg.png';
        }

        try {
            const user = await client.users.fetch(punishment.staff);
            punishment.staff = user.username;
        } catch (error) {
            punishment.staff = 'Unknown User';
        }
    
        // Check if the user is in the server
        try {
            const member = await guild.members.fetch(punishment.userID);
            punishment.userInServer = member ? 'The user is in the server' : 'The user is not in the server';
        } catch (error) {
            punishment.userInServer = 'The user is not in the server';
        }

    // Get the current logged-in user's member information
    const user = await guild.members.cache.get(req.user.id);
    const staffInfo = await staffModel.findOne({ userId: req.user.id });
    
    function getRelativeTime(date) {
        const currentDate = new Date();
        const targetDate = new Date(date);
        const timeDifference = currentDate.getTime() - targetDate.getTime();
    
        const seconds = Math.floor(timeDifference / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);
        const days = Math.floor(hours / 24);
    
        if (days > 0) {
            return days === 1 ? '1 day ago' : `${days} days ago`;
        } else if (hours > 0) {
            return hours === 1 ? '1 hour ago' : `${hours} hours ago`;
        } else if (minutes > 0) {
            return minutes === 1 ? '1 minute ago' : `${minutes} minutes ago`;
        } else {
            return seconds <= 20 ? 'just now' : `${seconds} seconds ago`;
        }
    }

    // Merge staffInfo into the user object
    if (staffInfo) {
        Object.assign(user, {
            roleName: staffInfo.roleName,
        });
    }
        
    function getFileExtension(url) {
        // Extract the file extension from the URL
        const fileExtensionMatch = url.match(/\.([0-9a-z]+)(?:[?#]|$)/i);
    
        if (fileExtensionMatch) {
            // If a file extension is found, return it
            return fileExtensionMatch[1];
        } else {
            // If no file extension is found, return an empty string
            return "";
        }
    }

        // Render the appeal form with the punishment data
        res.render('punishmentLookup', { user, existingAppeal, getFileExtension, guild, permissions: res.locals.permissions, getRelativeTime, config, successMessages: req.flash('success'), punishment });
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
});

app.post('/punishment/lookup/find', isLoggedIn(), async (req, res) => {

    const hasPermission = await utils.checkPermission(req.user.id, "LOOKUP_PUNISHMENTS");
    if(!hasPermission) return res.render('error', { config, errorMessage: `You don't have enough permissions to access this page!` });

    if(hasPermission) try {
        const { punishmentId } = req.body;
        const punishment = await punishmentModel.findOne({ punishmentID: punishmentId });

        if (!punishment || !punishmentId) {
            req.flash('error', 'Invalid Punishment ID');
            return res.redirect('/punishment/lookup');
        }

        res.redirect(`/punishment/lookup/${punishmentId}`);
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
});

app.post('/handleAction', isLoggedIn(), async (req, res) => {
    try {
        // Extract data from the request body
        const { action, userId, reason, noteText, dmMessage } = req.body;
        const guild = client.guilds.cache.get(config.GuildID);

        let punishmentID = await utils.generatePunishmentID();
        let success = false;
        let message = '';

        const user = await client.users.fetch(userId);
        if (!user) throw new Error('Invalid user');

        const member = await guild.members.fetch(userId);
        if (!member) throw new Error('Invalid member');

        const staff = await client.users.fetch(req.user.id);

        // Perform the action based on the action type
        if (action === 'kick') {
            const kickResult = await utils.kickUser(user, staff, reason, punishmentID);
            success = kickResult.success;
            message = kickResult.message;
        } else if (action === 'ban') {
            const banResult = await utils.banUser(user, staff, reason, punishmentID);
            success = banResult.success;
            message = banResult.message;
        } else if (action === 'note') {
            const noteResult = await utils.setNote(user, staff, noteText);
            success = noteResult.success;
            message = noteResult.message;
        } else if (action === 'dm') {
            const dmResult = await utils.dmUser(user, staff, dmMessage);
            success = dmResult.success;
            message = dmResult.message;
        }

        // Send success or error message based on the action result
        if (success) {

if(config.DashboardLogs) {
// Log the user action to the console
const consoleLogMsg = `${color.yellow(`[DASHBOARD] ${color.cyan(`${req.user.username} (${req.user.id})`)} performed ${color.cyan(action)} action for user with ID: ${userId}, reason: ${reason || noteText || dmMessage}`)}`;
console.log(consoleLogMsg);

// Log the user action to a file
const fileLogMsg = `\n[${new Date().toLocaleString()}] [DASHBOARD] ${req.user.username} (${req.user.id}) performed ${action} action for user with ID: ${userId}, reason: ${reason || noteText || dmMessage}`;
fs.appendFile("./logs.txt", fileLogMsg + '\n', (error) => {
    if (error) console.error('Error logging user action event:', error);
});
}

            res.json({ success: true, message: message });
        } else {
            res.json({ success: false, message: message });
        }
    } catch (error) {
        console.error('Error handling action:', error);
        res.status(500).json({ success: false, message: 'An error occurred while processing your request: ' + error.message });
    }
});






app.get('/', (req, res) => {
    if (req.isAuthenticated()) {
        res.redirect('/home')
    } else {
        res.redirect('/login');
    }
});

// Start the server
app.listen(PORT, () => { 
    let serverLogMsg = `\n[${new Date().toLocaleString()}] [SERVER] Server has started on port ${PORT}.`;
    fs.appendFile("./logs.txt", serverLogMsg, (e) => { 
        if(e) console.log(e);
    });

    console.log(color.yellow("[DASHBOARD] ") + `Web Server has started and is accessible with ${color.yellow(`${config.Dashboard.URL}`)}`)
});
const mongoose = require('mongoose');

const schema = new mongoose.Schema ({
    date: { type: Date, default: Date.now },
    kicks: { type: Number, default: 0 },
    bans: { type: Number, default: 0 },
    warns: { type: Number, default: 0 },
    timeouts: { type: Number, default: 0 },
    memberJoins: { type: Number, default: 0 },
    memberLeaves: { type: Number, default: 0 },
    messagesSent: { type: Number, default: 0 },
});

module.exports = mongoose.model('stats', schema);